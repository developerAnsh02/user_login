
package hiringsystem;


public class Staff {
    private int vacancy_no;
    private String designation;
    private String job_type;
    private String job_date;
    private String staffname;
    private String appointedby;
    private String qualification;
    private String salary;
    private String weekly_fractional_hours;
    private String joined;
    private String wages_per_hours;
    private String working_hours;
    private String shifts;
    
    
    
    public Staff(int vacancy_no,String designation,String job_type,String job_date,String staffname,String appointedby,String qualification,String salary,String weekly_fractional_hours,String joined,String wages_per_hours,String working_hours,String shifts){
    
        this.vacancy_no= vacancy_no;
        this.designation=designation;
        this.job_type=job_type;
        this.job_date=job_date;
        this.staffname=staffname;
        this.appointedby=appointedby;
        this.qualification=qualification;
        this.salary=salary;
        this.weekly_fractional_hours=weekly_fractional_hours;
        this.joined=joined;
        this.wages_per_hours=wages_per_hours;
        this.working_hours=working_hours;
        this.shifts=shifts;
    }

    Staff(int aInt, String string, String string0, String string1, String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9, String string10, String string11) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public int getvacancy_no(){
            return vacancy_no;
    }
    public String getdesignation(){
            return designation;
    }
    public String getjob_type(){
            return job_type;
    }
    public String getjob_date(){
            return job_date;
    }
    public String getstaffname(){
            return staffname;
    }
    public String getappointedby(){
            return appointedby;
    }
    public String getqualification(){
            return qualification;
    }
    public String getsalary(){
            return salary;
    }
    public String getweekly_fractional_hours(){
            return weekly_fractional_hours;
    }
    public String getjoined(){
            return joined;
    }
    public String getwages_per_hours(){
            return wages_per_hours;
    }
    public String getworking_hours(){
            return working_hours;
    }
    public String getshifts(){
            return shifts;
    }
}
