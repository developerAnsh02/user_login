-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2023 at 07:08 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employee`
--

-- --------------------------------------------------------

--
-- Table structure for table `fulltimestaff`
--

CREATE TABLE `fulltimestaff` (
  `vacancy_no` int(20) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `job_type` varchar(100) NOT NULL,
  `job_date` varchar(100) NOT NULL,
  `staffname` varchar(100) NOT NULL,
  `appointedby` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `salary` varchar(100) NOT NULL,
  `weekly_fractional_hours` varchar(100) NOT NULL,
  `joined` varchar(100) NOT NULL,
  `wages_per_hours` varchar(100) NOT NULL,
  `working_hours` varchar(100) NOT NULL,
  `shifts` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fulltimestaff`
--

INSERT INTO `fulltimestaff` (`vacancy_no`, `designation`, `job_type`, `job_date`, `staffname`, `appointedby`, `qualification`, `salary`, `weekly_fractional_hours`, `joined`, `wages_per_hours`, `working_hours`, `shifts`) VALUES
(256, 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'AN', '5', 'No', '785', '8', '45'),
(52, 'sample', 'sample', '01/01/2023', 'tony stark', 'someone', 'b.tech', '526354', '6', 'NA', '6', '8', 'Night');

-- --------------------------------------------------------

--
-- Table structure for table `parttimestaff`
--

CREATE TABLE `parttimestaff` (
  `vacancy_no` int(20) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `job_type` varchar(100) NOT NULL,
  `job_date` varchar(100) NOT NULL,
  `staffname` varchar(100) NOT NULL,
  `appointedby` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `salary` varchar(100) NOT NULL,
  `weekly_fractional_hours` varchar(100) NOT NULL,
  `joined` varchar(100) NOT NULL,
  `wages_per_hours` varchar(100) NOT NULL,
  `working_hours` varchar(100) NOT NULL,
  `shifts` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parttimestaff`
--

INSERT INTO `parttimestaff` (`vacancy_no`, `designation`, `job_type`, `job_date`, `staffname`, `appointedby`, `qualification`, `salary`, `weekly_fractional_hours`, `joined`, `wages_per_hours`, `working_hours`, `shifts`) VALUES
(52, 'IT', 'part Time', '01/01/2023', 'Sample', 'NA', 'b.Tech', '5464655', '5', 'No', '8', '6', 'Night'),
(53, 'sample', 'sample', '01/01/2023', 'sample', 'sample', 'sample', '4589630', '90', 'no', '60', '12', 'morning');

-- --------------------------------------------------------

--
-- Table structure for table `salarytable`
--

CREATE TABLE `salarytable` (
  `vacancy_no` int(20) NOT NULL,
  `staffname` varchar(200) NOT NULL,
  `salary` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `salarytable`
--

INSERT INTO `salarytable` (`vacancy_no`, `staffname`, `salary`) VALUES
(45, 'bsdyd', '5000'),
(52, 'tony stark', '5000000');

-- --------------------------------------------------------

--
-- Table structure for table `setworkingshifts`
--

CREATE TABLE `setworkingshifts` (
  `vacancy_no` int(20) NOT NULL,
  `staffname` varchar(100) NOT NULL,
  `weekly_fractional_hours` varchar(100) NOT NULL,
  `wages_per_hours` varchar(100) NOT NULL,
  `working_hours` varchar(100) NOT NULL,
  `shifts` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `setworkingshifts`
--

INSERT INTO `setworkingshifts` (`vacancy_no`, `staffname`, `weekly_fractional_hours`, `wages_per_hours`, `working_hours`, `shifts`) VALUES
(256, 'Tony', '9', '5', '12', 'Night'),
(52, 'tony stark', '85', '25', '13', 'night');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
