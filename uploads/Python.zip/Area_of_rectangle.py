Length = float(input("Enter the length of Rectangle: "))
Breadth = float(input("Enter the breadth of  Rectangle: "))

# Calculating the area of the Rectangle
Area = Length * Breadth

# Printing the area of the Rectangle
print("The area of rectangle is ", Area)

