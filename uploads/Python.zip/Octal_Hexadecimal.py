num = int(input("Enter a number: "))

# converting to octal and hexadecimal
octal = oct(num)
hexadecimal = hex(num)

# printing the results
print("The octal equivalent of", num, "is", octal)
print("The hexadecimal equivalent of", num, "is", hexadecimal)
