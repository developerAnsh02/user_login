# Defining matrices A and B
A = [[1, 2], [3, 4]]
B = [[4, 5], [6, 7]]

# 1. Displaying the elements of matrices A and B
print("Matrix A")
for row in A:
    print(row)

print("Matrix B")
for row in B:
    print(row)

#Addition
C = [[0, 0], [0, 0]] 
for i in range(len(A)):
    for j in range(len(B[0])):
        C[i][j] = A[i][j] + B[i][j]

# 3. Subtracting
D = [[0, 0], [0, 0]] 
for i in range(len(A)):
    for j in range(len(B[0])):
        D[i][j] = A[i][j] - B[i][j]

# 4. Displaying the output
print("A + B = ")
for row in C:
    print(row)

print("A - B = ")
for row in D:
    print(row)