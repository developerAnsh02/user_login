import random

# Function to generate a lottery ticket
def generate_ticket():
    Ticket = []
    for i in range(6):
        Ticket.append(random.randint(1, 59))
    return Ticket

# Generating 5 lottery tickets
Tickets = []
for i in range(5):
    Tickets.append(generate_ticket())

# Print the generated tickets
print("Generated Tickets:")
for Ticket in Tickets:
    print(Ticket)

# Select a winner
Winner = random.choice(Tickets)

# Print the winner ticket
print("Winner Ticket:")
print(Winner)
