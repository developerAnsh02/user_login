Base = float(input("Enter the base of triangle: "))
Height = float(input("Enter the height of  triangle: "))

# Calculating the area of the triangle
Area = 0.5 * Base * Height

# Printing the area of the triangle
print("The area of triangle is ", Area)
