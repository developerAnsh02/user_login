Radius = float(input("Enter the radius of circle: "))
pi = 3.14
Area = pi * (Radius ** 2)
print("The Area of the circle is ", Area)
