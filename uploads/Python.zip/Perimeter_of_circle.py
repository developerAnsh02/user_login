Radius = float(input("Enter the radius of the circle: "))
pi = 3.14
Perimeter = 2 * pi * Radius
print("The perimeter of the circle is", Perimeter)
