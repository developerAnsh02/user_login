import random

# create an empty list
My_List = []

# populate the list with 20 random numbers between 1 and 59
for i in range(20):
    My_List.append(random.randint(1, 59))

# print the original list
print("Original List:", My_List)

# find the largest element in the list
max_value = max(My_List)

# replace the largest element in the list with zero
max_index = My_List.index(max_value)
My_List[max_index] = 0

# print the updated list
print("Updated List:", My_List)

# calculate the average of the updated list
average = sum(My_List) / len(My_List)

# print the average
print("Average:", average)
